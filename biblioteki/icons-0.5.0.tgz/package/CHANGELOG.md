### 🍂 v0.5.0 (17.12.2021)

-   **feat**: New Icons

### 🍂 v0.4.0 (27.10.2021)

-   **feat**: New Icons

### 🌇 v0.3.1 (24.09.2021)

-   **chore**: Updated dependency

### 👻 v0.3.0 (20.09.2021)

-   **feat**: New Icons

### 🎉 0.2.2 (17.05.2021)

-   **chore**: Typescript dependency upgraded.

### 🦄 v0.2.1 (04.05.2021)

-   **chore**: Removed React dependency

### 🦄 v0.2.0 (08.02.2021)

-   **feat**: New Icons

### 🚨 v0.1.0 (10.09.2020)

-   **feat**: New Icons
