### 🦇 v0.4.0 (23.11.2022)

-   **chore**: Improved Tss Plugin

### 🍂 v0.3.2 (27.10.2021)

-   **chore**: Update dependencies

### 🌽 0.3.1 (06.09.2021)

-   **chore**: Update dependencies

### 🌈 v0.3.0 (16.07.2021)

-   **feat**: Build plugin updated to meet new theming requirements

### ☠ v0.2.0 (19.04.2021)

-   **feat**: Collect styles for SSR

### ⛽ v0.1.0 (30.03.2021)

-   **chore**: Improved build plugins

### 💉 v0.0.5 (29.01.2020)

-   **chore**: Improved build plugins

### 🚨 v0.0.4 (11.05.2020)

-   **chore**: Plugin rewriteStencilFCExport

### 🚨 v0.0.3 (10.09.2020)

-   **feat**: build scripts for lsg.shared
