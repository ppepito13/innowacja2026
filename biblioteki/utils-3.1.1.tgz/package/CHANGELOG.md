### 🎉 3.1.1 (17.05.2021)

-   **chore**: Typescript dependency upgraded.

### ⛽ v3.1.0 (30.03.2021)

**NON-BREAKING CHANGES**

-   **chore**: Updated dependencies

### 💉 v3.0.0 (29.01.2021)

**BREAKING CHANGES**

-   **feat**(_localization_): Moved functionality to lsg.shared.

### 🚨 v2.5.1 (05.11.2020)

-   **chore**(_package_): Updated lsg.plugin to v0.0.4

### 🚨 v2.5.0 (10.09.2020)

**FEATURES**

feat(Localization): Added missing english translations on page navigation

### 📧 v2.4.1 (22.06.2020)

**NON-BREAKING CHANGES**

-   **chore**(_package_): Updated e-mail addresses in package.json.

### 😷 v2.4.0 (30.03.2020)

**FEATURES**

-   **feat**: Upgrading Package.Json (Semver: Minor Versions); Hoisting dependencies

### 🎆 v2.3.1 (11.02.2020)

**FEATURES**

feat(Localization): Make en the default language, as this is a requirement for the CcsApprovalPanel
feat(Localization): Added missing english translations

**NON-BREAKING CHANGES**

-   **fix**: default xs viewport for SSR
-   **fix**: set language

### 🎅 v2.3.0 (06.12.2019)

**FEATURES**

-   **feat**: LsgConsole which can be configured in the future to only show logs in development environments

### ☁ v2.2.4 (21.11.2019)

**NON-BREAKING CHANGES**

-   **fix**: Utils: postinstall.js: Fix (try/catch; casing)
-   **fix**: Build: removed node-sass binary link in .npmrc

### ☁ v2.2.3 (11.11.2019)

**NON-BREAKING CHANGES**

-   **fix**: postinstall.js now calls process.exit()
-   **fix**: postinstall.js: fixed bug (casing); additionally added try/catch around main routine;

### 🍖 v2.2.2 (05.10.2019)

**NON-BREAKING CHANGES**

-   **chore**: postinstall.js is now properly built/transpiled.

### 🎨 v2.2.0 (21.10.2019)

**FEATURES**

-   **feat**(_Icons_): Added keyboard and fullscreen icons.
-   **feat**(_NodeUtils_): Added NodeUtils. This will not be exported from index (mixing node-time and run-time is not a good idea),
    so you need to import it directy via `from "@lsg/utils/dist/(esm|esm-es5|cjs)/NodeUtils`

### 🙉 v2.1.0 (26.09.2019)

**FEATURES**

-   **feat**: Added postinstall.js for console output from @lsg modules.

### 🙉 v2.0.1 (19.09.2019)

**NON-BREAKING CHANGES**

-   **fix**(ResizeEvents): Fixed resizeEvents not registering on browser resize event.

### 🎨 v2.0.0 (16.09.2019)

**BREAKING CHANGES**

-   **refactor**(_DateUtils_): DateUtils.minDate is now DateUtils.MINDATE, DateUtils.maxDate is now DateUtils.MAXDATE.
-   **refactor**(_Localization_): Is not a class anymore, so no constructor is being exported anymore. (no LocalizationClass export)

**FEATURES**

-   **feat**(i18n): Added german and english default texts for icons.
-   **feat**(_ResizeEvents_): Will now only register window listener when there are callbacks registered.
-   **feat**(_ResizeEvents_): Will now cleanup window listener when there are no callbacks registered.
-   **feat**(_ScrollEvents_): Will now only register window listener when there are callbacks registered.
-   **feat**(_ScrollEvents_): Will now cleanup window listener when there are no callbacks registered.

**NON-BREAKING CHANGES**

-   **refactor**: Internal cleanup.

### 🙏 v1.0.4 (05.09.2019)

**FEATURES**

-   **feat**(_NavigationUtils_): Moved from @lsg/components to @lsg/utils.

**NON-BREAKING CHANGES**

-   **chore**: Moved typings from dist/esm folder to dist/types - won't break because of package.json entry targets
-   **chore**: Remove stencil dependency
-   **bugfix**: German date placeholder

### 🐘 v1.0.3 (23.08.2019)

**NON-BREAKING CHANGES**

-   **chore**: Making things work in @lsg/components and @lsg/webcomponents

### 🐭 v1.0.1 (16.08.2019)

**NON-BREAKING CHANGES**

-   **chore**: Fixed wrong export in index.ts.

### 😿 v1.0.0 (15.08.2019)

**FEATURES**

-   **chore**: Initial commit.
