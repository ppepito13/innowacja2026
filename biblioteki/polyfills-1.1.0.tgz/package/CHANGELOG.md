### 🌽 1.1.0 (06.09.2021)

-   **chore**: Rollup is now a devDependency instead of a dependency

### 🌈 v1.0.1 (16.07.2021)

**NON-BREAKING CHANGES**

-   **chore**: npm rc

### ⛽ v1.0.0 (30.03.2021)

**BREAKING CHANGES**

-   **chore**: Removed lsg.webcomponents support and dependecies. Use @lsg/webcomponents-polyfills if the webcomponents are still used.

### 💉 v0.0.13 (29.01.2021)

-   **feat**: Chore: Update lsg.webcomponents to 5.2.1

### 🝙 v0.0.11 (26.11.2020)

-   **feat**: Chore: Update lsg.webcomponents to 5.2.1

### 🚨 v0.0.10 (05.11.2020)

-   **feat**: Chore: Update lsg.webcomponents to 5.2.0

### 🚨 v0.0.9 (10.09.2020)

-   **feat**: ie11-custom-properties added

### 😷 v0.0.8 (22.06.2020)

-   **chore**: increase version

### 📧 v0.0.6 (14.05.2020)

-   **chore**: Updated e-mail addresses in package.json.

### △ v0.0.4 (04.01.2020)

-   **chore**: increase version

### 😷 v0.0.3 (30.03.2020)

-   **chore**: increase version
