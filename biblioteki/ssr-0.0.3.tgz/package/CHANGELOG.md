### 🍂 0.0.3 (27.10.2021)

-   **chore**: update dependencies

### 🌈 v0.0.2 (16.07.2021)

**NON-BREAKING CHANGES**

-   **chore**: git-ignore

### ☠ v0.0.1 (19.04.2021)

initial release
