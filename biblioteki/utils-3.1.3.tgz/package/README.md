This package contains helper methods for the @lsg/components and @lsg/webcomponents packages.<br>
**This has automatic Changelog generation integrated on `npm version [ patch | minor | major ]` - please provide useful commit messages.<br>
Stick to Angular commit message guidelines: https://github.com/angular/angular/blob/master/CONTRIBUTING.md#-commit-message-guidelines**
<br><br>
## DateUtils

Available constants:
- minDate - the minimum possible Date in Javascript (1.1.100)
- maxDate - the maximum possible Date in Javascript (31.12.9999)

Available functions:
- getCurrentLocale
- getLocaleDateFormat
- getLocaleDays
- autoDateSeparator

#### getCurrentLocale
##### (): Object
Returns a date-fns locale based on the current browser language.

#### getLocaleDateFormat
##### (width: "full" | "long" | "medium" | "short"): string
Returns the Date format in the provided width from the current locale.

#### getLocaleDays
##### (width: "narrow" | "short" | "abbreviated" | "wide"): string
Returns the Day format in the provided width from the current locale.

#### getLocaleDays
##### (value: string, minDate = DateUtils.minDate, maxDate = DateUtils.maxDate): string
Automatically formats a (partial) date string.
This will do the following:
- Add locale specific separator (. / -) automatically.
- Check & correct impossible date strings based on the locale (68 --> 31, 31.02 --> 29.02, 29.02.2013 --> 28.02.2013 etc.) 


## DomUtils

Available functions:
- isTargetInsideContainer
- findParentWithTagName
- overrideFocusTarget
- jsx
- cleanupClassNames

#### isTargetInsideContainer
##### (target: EventTarget | HTMLElement, container: HTMLElement): boolean
Recursive function to check if first parameter (target) is inside the seconds parameter (container) DOM child structure.

#### findParentWithTagName
##### (child: Element, tagName: string): Element | false
Recursive function that checks the first parameters (child) parentElements to find the first parent that matches the string passed as the second parameter (tagName).

#### overrideFocusTarget
##### (calledOnElm: HTMLElement, focusTarget: HTMLElement): void
Set the .focus() method of the element passed as first parameter (calledOnElm) to focus the element passed as second parameter (focusTarget).

#### jsx
##### (s: string): HTMLElement
Pass a string containing html/jsx tags to generate an HTMLElement that can added to the DOM.

#### cleanupClassNames
##### (classNames: string[]): string
Pass an array of classNames - this function will filter out any falsy values and then join the remaining values using a space.


## EventUtils

Available function:
- dispatch

#### dispatch
##### (element: HTMLElement, name: string): void
This function will emit an event with the given second parameter (name) from the given element as first parameter (element).


## HTMLUtils

Available functions:
- isHTMLAttr
- getHTMLAttrs

#### isHTMLAttr
##### (attribute: string, interfaces?: any[], noFilter?: boolean): boolean
Checks if the attribute passed as first parameter is within any of the interfaces passed as second parameter (ex.: `[HTMLDivElement, HTMLTableElement]`).
By default this will return false for the following attributes: id, class, aria-* -- you can prevent this behaviour by passing true as third parameter (noFilter).

#### getHTMLAttrs
##### (attrs: NamedNodeMap | any[], interfaces?: any[], options?: { omit: string[] }): string[]
Checks if attributes passed as first parameter (attrs) are within any of the interfaces passed as second parameter (interfaces).
Will return an array containing the names of the attributes that are. You can pass an options object as third parameter.
Using the `omit` option will remove any of the passed attributes from the functions return value. 


## Localization

Available exports:
- Localization
- LocalizationClass

#### Localization
This export is a pre-instanciated instance of LocalizationClass. See documentation below.

#### LocalizationClass

Available functions:
- [static] getBrowserLanguage - returns the current browserLanguage as a string
- refresh - refreshes the current browserLanguage kept inside the class instance
- setLanguage - overrides the current browserLanguage with a provided string
- getIconTitle - get the Icon title from the translation resources (pass the name as string)
- withField - ?


## NavigationUtils
... some util functions to handle objects within Navigations (SideNavigation, PortalNavigation etc.)


## SelectionNavHelper

Available functions:
- useKeyMap
- getFocusHandler

#### useKeyMap
##### ( event: KeyboardEvent | React.KeyboardEvent<HTMLButtonElement>, keyMap: A11yKeyMap & { [index: string]: KeyHandlerFn | KeyHandlerObj }, focusHandler?: IA11yFocusHandler)
Useful in keyHandler functions. Pass the KeyboardEvent as the first parameter (event). The second paramter shall be a keyMap looking like this:
`
    [Key.Escape]: () => doSomething(),
    [Key.ArrowUp]: () => doSomethingElse(),
    [Key.ArrowDown]: {
        fn: () => doSomethingFancy(),
        noPreventDefault: true,
        allowShift: true,
        allowCtrl: true,
        allowAlt: true
    },
`
The third parameter is optional. Pass the return value of `getFocusHandler` if necessary - see documentation below.

#### getFocusHandler
##### ( values?: any[] | any[][], activeValue?: any ): IA11yFocusHandler
Pass an array (1 dimensional) or an array containing arrays (2 dimensional) as first parameter (values). Pass the activeValue as the second parameter - this has to be within the values. 
This will return an object looking like:
`
    {
       curr: () => any, 
       first: () => any, 
       last: () => any, 
       next: cb => any, 
       prev: cb => any, 
       // only if values is 2 dimensional:
       above: cb => any,
       below: cb => any,
    }
`
This can be used to easily navigate within the values list/map. cb will be called when there is no next/prev/above/below element.


## ViewportUtils

### getMobileFirstValue(definitions: {}, viewport: string)

`import { getMobileFirstValue } from "../../../utils/ViewportUtils";`

## WindowEvents

`import { WindowEvents } from "../../../../utils/WindowEvents";`

The WindowEvents utils are a wrapper for events on the window object, like scroll and resize events. It provides LSG-specific
functionality like listening for viewports changes and compensating sticky elements like the Header for scroll events.
Further features are visibility events to detect when an HTML Element is visible at the current scroll position.

There are two things that should be noted. In terms of performance, the callback should be used that is most suitable to
the needs of the developer. E.g. if a component needs to be notified if the viewport changes, both the resize listener
and the viewport listener can be used. However, the viewport listener is called only when a resize will cause a
viewport change, and is called less times. In terms of performance, the viewport listener should be called in such cases.
A second thing that should be noted is that every event listener which is added for a component needs to be removed
before unmounting it.

Example:

```js static
class myComponent extends React.Component {
    componentDidMount() {
        // register event listener
        WindowEvents.addResizeCallback(this.handleResize);
    }

    componentWillUnmount() {
        // unregister before component will be unmounted
        WindowEvents.removeResizeCallback(this.handleResize);
    }

    handleResize = () => {
        // ...
    };
}
```

### Resize

Resize events are triggered when the browser size changes or a mobile device is flipped.

`WindowEvents.addResizeCallback(callback: () => void)`

`WindowEvents.removeResizeCallback(callback: () => void)`

### Ratio

Ratio events are triggered, when the browser size and as a result the orientation changes. When needed in css, a media
query with a ratio selector should be used.

`WindowEvents.addRatioCallback(minRatio: number, callback: (isLargerThan: boolean) => void)`

`WindowEvents.removeRatioCallback(callback: (isLargerThan: boolean) => void)`

### Viewport

Viewport events are triggered, when the browser size and as a result the viewport changes.

`WindowEvents.addViewportCallback(callback: (viewportSize: string) => void)`

`WindowEvents.removeViewportCallback(callback: (viewportSize: string) => void)`

`WindowEvents.getViewportSize()`

### Scroll

Scroll events are triggered when the page is scrolled. Scrolling that is done inside an HTML element with
`overflow: scroll;` are not triggered.

`WindowEvents.addScrollCallback(callback: () => void)`

`WindowEvents.removeScrollCallback(callback: () => void)`

### Visibility

Visibility events are triggered for elements, that change their visibility. For details see the implementation of the
`<JumpLinks />` component.

`WindowEvents.addVisibilityCallback(callback: (elementIds?: string[]) => void, elementIdsToWatch?: string[], visibility?: Visibility, offset?: number)`

`WindowEvents.removeVisibilityCallback(callback: (elementIds?: string[]) => void`

### Sticky elements

For sticky elements, the helpers are also part of the `WindowEvents.tsx` file.

`WindowEvents.addStickyElement(name: string, elm: HTMLElement)`

`WindowEvents.removeStickyElement(name: string)`

`WindowEvents.getStickyElements()`

returns `Array<{ name: string; elm: HTMLElement }>`

`WindowEvents.getStickyElementsHeight()`
