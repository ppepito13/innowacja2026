### ❅ 1.14.0 (17.12.2021)

**NEW COMPONENTS**

_ProfileWidget_, _SeparatorLine_, _BarChart_, _InfoAreaItem_, _TanNotification_, _ThumbnailLink_,

**FEATURES**

-   **feat**(_Textfield_): Added optional InputSelect component for e.g. currency choice
-   **feat**(_Datepicker_): Option for enabling/disabling holidays, workdays, weekends

**NON-BREAKING CHANGES**

-   **fix**(_Pagination_): Disabled pagination arrow (icon link) now gets appropriate color.
-   **fix**(_Slider_): bypass restriction of max-width given by css-f()-styleTypo2 and replace styleTypo from parent to child elements
-   **fix**(_DatePickerFlyout_): Use proper whitespaces to prevent encoding issues. Since no encoding issues were reproducible, this is not guaranteed to fix them, but rather a general improvement that may help.
-   **feat**(_ProfileWidget_): Profile Widget for PK Portal (Header).
-   **fix**(_Layer_): Layer header now is sticky and added Layer-right-25 to the Layouts
-   **fix**(_PortalHeader_): Mobile drawer menu header is now sticky
-   **fix**(_ProcessPage_): Mobile drawer menu header is now sticky
-   **fix**(_ProcessPage_): Mobile header width issue
-   **fix**(_ProcessPage_): Mobile header (with no menu): Label has ellipsis now
-   **fix**(_SimpleHeader_): Mobile drawer menu header is now sticky
-   **fix**(_Button_): Button has now minWidth on SmMin Viewport
-   **feat**(_Drawer_): Added Layer-right-25 to the LayoutClasses
-   **feat**(_IconLinkGroup_): Added centeredLayout property
-   **feat**(_Logo_): header logo props reworked
-   **feat**(_Select_): Added property hiddenSelectIcon
-   **feat**(_TanPanel_): Now in Design 5.0 with TanNotification
-   **feat**(_TwoLineItem_): Added experimental spacing

### 🦇 1.13.0 (23.11.2021))

**NEW COMPONENTS**

-   **feat**(_ProfileWidget_): Profile Widget for PK Portal (Header).

**FEATURES**

-   **feat**(_Tabs_): Badges for Tab labels.
-   **feat**(_Tabs_): CentredLayout support added.
-   **feat**(_BarDiagram_): The thickness of the bar is now larger on large viewports.
-   **feat**(_ClickList_): Added support for checkbox and radio items inside a `ClickList`.
-   **feat**(_StatusIndicator_): Introduced state "Neutral" (grey).
-   **feat**(_StatusIndicator_): Added HelperText for StatusIndicator.
-   **feat**(_ActionGroup_): Centering items with the `centeredLayout` prop, if only one button area ist defined.

**NON-BREAKING CHANGES**

-   **fix**(_Snackbar_): Snackbar is now vertically centered and the padding has been adjusted.
-   **fix**(_Button_): Buttons now have a min-width for the middle viewport.
-   **fix**(_DatePicker_): Open or reopen of flyout shows the selected value, when it exists. Otherwise focussed value.
-   **fix**(_List_): Long texts now break and don't overlap listicons.
-   **fix**(_Link_): Links have a word-break now so they don't break narrow/mobile layouts.
-   **fix**(_TwoLineItems_): Ids and classNames can be passed.
-   **fix**(_SelectOption_): The `disabled` prop of a SelectOption now works correctly.

**BREAKING CHANGES**

-   **chore**(_Cards_): Refactored API for checkbox and radio items to resemble `ClickList`, `Radio` and `Checkbox`.

### 🍂 1.12.0 (27.10.2021)

**NEW COMPONENTS**

_SideNavigationPage_

**FEATURES**

-   **feat**(_Slider_): complete rework to support single and range slider types
-   **feat**(_InputTextSlider_): combination of input text field(s) and Slider in single and range slider types
-   **feat**(_Video_): Added track element and props to Video component to support caption (subtitel) files.

**NON-BREAKING CHANGES**

-   **fix**(_ComplexTable_): The stretching issue to complete width within Grid-Column is solved
-   **fix**(_DatePicker_): Given value with `undefined` will mapped to empty string, similar to initialisation in Textfield.stateful that placeholder become displayed
-   **fix**(_DatePicker_, _Textfield_): The standard "en" language format is now DD/MM/YYYY instead of MM/DD/YYYY
-   **fix**(_IconLinkGroup_): Fixed vertical scrollbar on legacy browsers
-   **fix**(_Video_): Added missing faulty video src error handling
-   **fix**(_Icon_): If `id` prop is undefined, a unique id will be set.
-   **fix**(_Icon_): If `title` prop is not set, the corresponding or default title is used. Set `title=""` if you require an empty title.

### 🌇 1.11.0 (24.09.2021)

**FEATURES**

-   **feat**(_Icon_): Badge (Indicator on top right corner)
-   **feat**(_IconLink_): Badge (Indicator on top right corner)
-   **feat**(_ComplexTable_): New Feature rowActionsLook which gives you some variants to display the action icons

**NON-BREAKING CHANGES**

-   **fix**(_ComplexTable_): Fixed offsetWidth exception
-   **fix**(_IconLinkGroup_): Fixed overflowing right margin
-   **fix**(_Section_): Fixed overflowing right margin; also fixes GallerySlider right overflow issue

### 🌽 1.10.0 (06.09.2021)

**FEATURES**

-   **feat**(_CircleDiagram_): CTA Button, headline and Refresh countdown
-   **feat**(_ClickList_): Option for no linkIcon when in disabled state

**NON-BREAKING CHANGES**

-   **fix**(_Video_): Poster image now working
-   **fix**(_FormLink_): Component Overworked
-   **fix**(_PortalHeader_): Resizing issue
-   **fix**(_PortalHeader_): Segment switch added for mobile-view
-   **fix**(_TanPanel_): Info text (Layer) will now appear from the right window side (instead of left).
-   **fix**(_Select_): Fix: Textfield Id now fits the labelFor attribute.
-   **fix**(_Datepicker_): Fix: Textfield Id now fits the labelFor attribute.
-   **fix**(_DatePicker_): minDate, maxDate and value are now filtered and dates out of range don't highlight.
-   **fix**(_Grid_): Id and className of Grid, Grid.Row and Grid.Column can now be set properly.

### 🌈 v1.9.0 (16.07.2021)

**FEATURES**

-   **feat**: Improved white label capabilities
-   **feat**: New Date Picker Variant "Monthpicker"
-   **feat**: SuffixOption for InputTextField

**NON-BREAKING CHANGES**

-   **fix**(_InputCheckbox_): Console.log error
-   **fix**(_InputRadio_): Fixed group layout errors
-   **fix**(_InputCheckbox_): Fixed group layout errors
-   **feat**(_Cards_): Maximal row length
-   **feat**(_Cards_): Selection cards completely clickable
-   **fix**(_Cards_): Minor layout fixes
-   **fix**(_DatePicker_): do not render calendar icon in `readOnly` state
-   **fix**(_DatePicker_): adjust flyout of datepicker to small viewports
-   **fix**(_DatePicker_): add missing gap under input
-   **fix**(_ComplexTable_): Set table width to 100% independently from viewport
-   **fix**(_Grid_): Grid, Grid.Row, Grid.Column id and className can be set properly now.

**BREAKING CHANGES**

-   **feat**(_ProductStage_): Added highlight prop to make ProductStage capable of showing highlights even without products. Deprecated `highlightProduct` prop in the process.

### 🐑 v1.8.0 (11.06.2021)

**NEW COMPONENTS**

_FormLink_

_Cards_

**FEATURES**

-   **feat**(_LineChart_): Added loadingIndicator
-   **fix**(_LineChart_): Several things fixed

**NON-BREAKING CHANGES**

-   **fix**(_Section_): Fixed color of separator
-   **fix**(_Subsection_): Fixed color of separator

### 🎉 v1.7.0 (17.05.2021)

**FEATURES**

-   **feat**(_BarDiagram_): Added some features
-   **feat**(_ProductStage_): Added some props
-   **feat**(_Grid_): CenteredLayout prop

**NON-BREAKING CHANGES**

-   **fix**(_TabBar_): Indicator set at first render
-   **fix**(_Footer_): Repaired broken mobile layout
-   **fix**(_ArticleStage_): Subline now takes ReactElements as children
-   **fix**(_ArticleStage_): HelperText prop is now working
-   **fix**(_Headline_): centeredLayout prop now works on overline, if defined as span
-   **fix**(_Banking Cards_): noNFC prop is now working correctly

### 🚀 v1.6.0 (04.05.2021)

**FEATURES**

-   **feat**(_BankingCard_): New debit card image for card design: "giro". Previous image is available via card="giro_old".

### ☠ v1.5.0 (19.04.2021)

**FEATURES**

-   **feat**(_List_): List can be displayed with a leading icon
-   **fix**: onClick, onFocus and onBlur events now consistently provides the event as the first callback prop.
    Previously, this lead to confusions. This change may cause problems with the existing implementations.
-   **feat**: support for collecting styles during server side rendering.
-   **doc**: Cross-Component concerns are now documented in the markenportal under "Developer Guidelines".
-   **feat**(_Video_): Full-Screen Video now has the LSG-Styling
-   **feat**: WebP support for Stages

**NON-BREAKING CHANGES**

-   **fix**(_ProcessPage_): Fixed types of navigationTree prop.
-   **chore**: Various (internal) typings for navigationTrees

### ⛽ v1.4.0 (30.03.2021)

**NEW COMPONENTS**

_ComplexTable_, _Slider_, _EyeCatcher_, _Stage_, _SimpleFooter_ and more

Various new components, features and bug fixes

### 💉 v1.3.0 (29.01.2021)

Various new components, features and bug fixes

### 🐒 v1.2.0 (04.12.2020)

**NEW COMPONENTS**

_CircleIconLink_, _ActionButton_, _LineChart_, _TabBar_

**FEATURES**

-   **feat**(_Headline_): added Iconlink option

### 🝙 v1.1.1 (26.11.2020)

-   **fix**: missing type-only import

### 🍯 v1.1.0 (05.11.2020)

**NEW COMPONENTS**

_AutoComplete_, _BannerMessage_, _CardContainer_, _ClickList_, _IconCard_, _Indicator_, _MessageContainer_,
_NavigationBar/-Block/-Item_, _OnPageNavigation_, _PortalMetaBar_, _ProcessMetaBar_, _ProcessMetaBarLink_,
_ProcessPage_, _ProductStage_, _Select_, _SelectFlyout_, _SelectionCard(-Group)_, _SnackBar_, _StatusIndicator_,

### 🚨 v1.0.0 (10.09.2020)

**NEW COMPONENTS**

ActionGroup, ArticleList, ArticleStage, Button, DescriptionList, Grid, Headline, Icon, IconLink, Layer, Link, List, Paragraph, Picture, Section, SelectionCard, SelectionCardGroup, Spinner, Stepper, Teaser, Theme, Thumbnail, TipsTricks
